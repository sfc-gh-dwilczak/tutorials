SELECT 'Hello World from a SQL query' AS greeting;
