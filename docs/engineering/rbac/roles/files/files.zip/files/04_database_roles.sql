-- Database Roles
-- Read
-- Write

use role engineer;
create database role development.read;
create database role development.write;
grant database role development.read to database role development.write;

create database role raw.read;
create database role raw.write;
grant database role raw.read to database role raw.write;

create database role bronze.read;
create database role bronze.write;
grant database role bronze.read to database role bronze.write;

create database role silver.read;
create database role silver.write;
grant database role silver.read to database role silver.write;

create database role gold.read;
create database role gold.write;
grant database role gold.read to database role gold.write;

use role accountadmin;
create database role security.read;
create database role security.write;
grant database role security.read to database role security.write;