--- Warehouses
-- role name (Could have multi sizes for example engineer_xs, engineer_m) (Consider multi-clustering)
-- service_<application>

use role sysadmin;

create warehouse engineer_xs with warehouse_size = 'XSmall' auto_suspend = 30;
create warehouse engineer_s with warehouse_size = 'Small' auto_suspend = 30;
create warehouse engineer_m with warehouse_size = 'Medium' auto_suspend = 30;

grant usage on warehouse engineer_xs to role engineer;
grant usage on warehouse engineer_s to role engineer;
grant usage on warehouse engineer_m to role engineer;

create warehouse analyst_xs with
    warehouse_size = 'XSmall'
    auto_suspend = 30;
    --min_cluster_count = 1
    --max_cluster_count = 3
    
grant usage on warehouse analyst_xs to role analyst;

--- Optional
-- create warehouse service_dbt with warehouse_size = 'XSmall' auto_suspend = 30;
-- grant usage on warehouse service_dbt to role service_dbt;