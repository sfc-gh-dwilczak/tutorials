use role accountadmin;

--- High level Roles
create role engineer;
create role analyst;

-- Create hierarchy
grant role analyst to role engineer;
grant role engineer to role sysadmin;

--- Optional
-- create role service_dbt;

 --create role service_fivetran;
--grant database role raw.write to role service_fivetran;


