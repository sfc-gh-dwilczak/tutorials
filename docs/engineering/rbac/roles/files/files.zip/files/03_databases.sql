--- Database Objects
-- Development (All role have write access) (Schemas require First initial lastname - DWilczak)
-- Raw
-- Bronze
-- Silver
-- Gold
-- Security
-- Share_Name (Data Share naming convention)

create database development;

create database raw;
create database bronze;
create database silver;
create database gold;

create database security;

grant ownership on database development to role engineer;
grant ownership on database raw to role engineer;
grant ownership on database bronze to role engineer;
grant ownership on database silver to role engineer;
grant ownership on database gold to role engineer;
grant usage on database security to role engineer;