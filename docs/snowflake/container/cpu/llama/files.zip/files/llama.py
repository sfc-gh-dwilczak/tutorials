from flask import Flask, request, jsonify, make_response
import logging
import os
import sys
from llama_cpp import Llama


def get_logger(logger_name):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter(
            '%(name)s [%(asctime)s] [%(levelname)s] %(message)s'))
    logger.addHandler(handler)
    return logger

logger = get_logger('llm')

app = Flask("Llama server")
model = None

@app.get("/healthcheck")
def readiness_probe():
    return "I'm ready!"

@app.post('/llama')
def generate_response():
    """
    Main endpoint to access the llama model. Snowflake operates on tables
    so the input is in a row based. An example below will explain:

    Example input:

    {
        "data": [
            [0, "You are a helpful assistant", "Generate a list of 5 funny dog names", 100],
            [1, "You are a helpful assistant", "Generate a list of 5 funny cat names", 100]
        ]
    }

    Inputs = [0, "System message", "LLM prompt/request.", Number of token (aka words to use.) ]
    
    """

    message = request.json


    input_rows = message['data']


    output_rows = [[row[0], llm(row[1],row[2],row[3])] for row in input_rows]
    

    response = make_response({"data": output_rows})
    response.headers['Content-type'] = 'application/json'
    
    return response


def llm(system_message,user_message, max_tokens):

    global model

    prompt = f"""<s>[INST] <<SYS>>
    {system_message}
    <</SYS>>
    {user_message} [/INST]"""
    
    # Create the model if it was not previously created
    if model is None:
        model_path = "./llama-2-7b-chat.Q2_K.gguf"
        model = Llama(model_path=model_path)
        
    # Run the model
    output = extract_text_after_inst(model(prompt, max_tokens=max_tokens, echo=True))
    
    return output

def extract_text_after_inst(data):
    # Extract the text from the first choice (assuming there's only one choice for simplicity)
    text = data["choices"][0]["text"]
    
    # Find the position of "[/INST]" in the text
    inst_end_pos = text.find("[/INST]")
    
    # Extract the text after "[/INST]" if it exists, otherwise return an empty string
    if inst_end_pos != -1:
        return text[inst_end_pos + len("[/INST]"):].strip()
    else:
        return ""


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
