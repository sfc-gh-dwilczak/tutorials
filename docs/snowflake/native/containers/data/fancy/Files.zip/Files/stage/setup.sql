create application role app_role;
create schema if not exists app_schema;
grant usage on schema app_schema to application role app_role;

------ When you click the activate button ------
create or replace procedure app_schema.grant_privileges(privileges array)
  returns string
  language sql
  execute as owner
as
begin
    execute immediate $$create warehouse app_warehouse with warehouse_size = 'XSMALL'$$;

    execute immediate $$create compute pool app_pool min_nodes=1 max_nodes=1 instance_family=cpu_x64_xs auto_resume=true$$;

    execute immediate $$create service app_service in compute pool app_pool from specification_file='website.yaml' query_warehouse=app_warehouse$$;

    grant service role app_service!ALL_ENDPOINTS_USAGE to application role app_role;
end;

grant usage on procedure app_schema.grant_privileges(array) to application role app_role;

